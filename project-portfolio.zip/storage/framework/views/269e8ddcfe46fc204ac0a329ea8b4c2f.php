<footer class="section-sm bg-tertiary">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-2 col-md-4 col-6 mb-4">
                <div class="footer-widget">
                    <h5 class="mb-4 text-primary font-secondary">Service</h5>
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $footerServices ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-2">
                                <a href="<?php echo e(route('services.show', $service->id)); ?>"><?php echo e($service->title); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-6 mb-4">
                <div class="footer-widget">
                    <h5 class="mb-4 text-primary font-secondary">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="<?php echo e(route('about')); ?>">About Us</a>
                        </li>
                        <li class="mb-2"><a href="<?php echo e(route('contact')); ?>">Contact Us</a>
                        </li>
                        <li class="mb-2"><a href="<?php echo e(route('blogs')); ?>">Blog</a>
                        </li>
                        <li class="mb-2"><a href="<?php echo e(route('teams')); ?>">Team</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-6 mb-4">
                <div class="footer-widget">
                    <h5 class="mb-4 text-primary font-secondary">Other Links</h5>
                    <ul class="list-unstyled">
                        <li class="list-inline-item me-4"><a class="text-black" href="<?php echo e(route('privacy')); ?>">Privacy
                                Policy</a>
                        </li>
                        <li class="list-inline-item me-4"><a class="text-black" href="<?php echo e(route('terms')); ?>">Terms &amp;
                                Conditions</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\ZULFIKER HOSSAIN\Desktop\project-portfolio\resources\views/front/layouts/footer.blade.php ENDPATH**/ ?>