
<?php $__env->startSection('title', $meta_title ?? 'Faq - Web App'); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <section class="section">
            <div class="container">
                <div class="row justify-content-center mb-5">
                    <div class="col-lg-6">
                        <div class="section-title text-center">
                            <p class="text-primary text-uppercase fw-bold mb-3">Frequient Questions</p>
                            <h1>Frequently Asked Questions</h1>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-9">
                        <div class="accordion accordion-border-bottom" id="accordionFAQ">
                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header accordion-button h5 border-0 <?php echo e($loop->first ? 'active' : ''); ?>"
                                        id="heading-<?php echo e($faq->id); ?>" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse-<?php echo e($faq->id); ?>"
                                        aria-expanded="<?php echo e($loop->first ? 'true' : 'false'); ?>"
                                        aria-controls="collapse-<?php echo e($faq->id); ?>">
                                        <?php echo e($faq->title); ?>

                                    </h2>
                                    <div id="collapse-<?php echo e($faq->id); ?>"
                                        class="accordion-collapse collapse border-0 <?php echo e($loop->first ? 'show' : ''); ?>"
                                        aria-labelledby="heading-<?php echo e($faq->id); ?>" data-bs-parent="#accordionFAQ">
                                        <div class="accordion-body py-0 content">
                                            <?php echo e($faq->description); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_backup', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ZULFIKER HOSSAIN\Desktop\project-portfolio\resources\views/front/faq.blade.php ENDPATH**/ ?>