
<?php $__env->startSection('title', $meta_title ?? 'PagesEdit - Admin'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="card shadow-lg">
            <!-- Card Header -->
            <div class="card-header bg-primary text-white">
                <h4>Edit Post</h4>
            </div>

            <!-- Card Body -->
            <div class="card-body">
                <form action="<?php echo e(route('admin.pages.update', $pages->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <!-- Title -->
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input type="text" name="title" id="title" class="form-control" placeholder="Enter title"
                            value="<?php echo e($pages->title ?? ''); ?>">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Description -->
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea style="height: 100px;" name="description" class="form-control" id="summernote"><?php echo e(old('description', $pages->description ?? '')); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            </div>

            <!-- Card Footer -->
            <div class="card-footer text-end">
                <button type="submit" class="btn btn-success">Save Post</button>
                <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-secondary">Back</a>
            </div>
            </form>
        </div>
    </div>
    <script>
        document.getElementById('title').addEventListener('keyup', function() {
            let val = this.value;

            let slug = val.toLowerCase()
                .replace(/ /g, '-')
                .replace(/[^\w\-অ-হ]/g, '');

            document.getElementById('slug').value = slug;
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#summernote').summernote({
                height: 200
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ZULFIKER HOSSAIN\Desktop\project-portfolio\resources\views/admin/pages_edit.blade.php ENDPATH**/ ?>