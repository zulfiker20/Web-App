<!DOCTYPE html>
<html lang="en-us">

<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="author" content="Themefisher">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">

    <!-- # Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- # CSS Plugins -->
    <link rel="stylesheet" href="<?php echo e(asset('front/plugins/slick/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/plugins/font-awesome/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/plugins/font-awesome/brands.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/plugins/font-awesome/solid.css')); ?>">

    <!-- # Main Style Sheet -->
    <link rel="stylesheet" href="<?php echo e(asset('front/css/style.css')); ?>">
    <style>
        .fl-wrapper {
            position: fixed !important;
            bottom: 20px;
            /* Distance from bottom */
            right: 20px;
            /* Distance from right */
            top: auto !important;
            /* Override top */
            z-index: 9999 !important;
        }

        .bg-dark {
            --bs-bg-opacity: 1;
            background-color: red !important;
        }
    </style>
</head>

<body>
    <?php echo $__env->make('front.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('front.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- # JS Plugins -->
    <script src="<?php echo e(asset('front/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front/plugins/bootstrap/bootstrap.min.js')); ?>"></script>

    <!-- Main Script -->
    <script src="<?php echo e(asset('front/js/script.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\ZULFIKER HOSSAIN\Desktop\project-portfolio\resources\views/layouts/guest.blade.php ENDPATH**/ ?>